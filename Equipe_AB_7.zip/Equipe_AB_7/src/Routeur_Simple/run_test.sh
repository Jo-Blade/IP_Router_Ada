./test_ip
./test_liste_chainee
./test_my_strings
./test_split
./test_routage
